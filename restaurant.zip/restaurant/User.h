//
// Created by micha on 27.04.2022.
//

#ifndef RESTAURANT_USER_H
#define RESTAURANT_USER_H
#include "string"

class User {
    int userId;
    std::string login;
    std::string email;
    std::string password;
    std::string name;
    std::string surname;
    std::string username;
};


#endif //RESTAURANT_USER_H
