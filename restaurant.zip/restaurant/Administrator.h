//
// Created by kinga on 07.05.2022.
//

#ifndef RESTAURANT_ADMINISTRATOR_H
#define RESTAURANT_ADMINISTRATOR_H


class Administrator {

};


#endif //RESTAURANT_ADMINISTRATOR_H
